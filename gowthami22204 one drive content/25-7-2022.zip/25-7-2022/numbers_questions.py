1.#write a program to find the sum of the numbers
'''num=int(input("enter the number="))
add=0
for i in range(num+1):
    add +=i
    num-=1
print("sum of the number=",add)'''

#input:
enter the number=12
#output:
sum of the number= 78


2.#WAP to print the given number is strong number or not
'''#strong number
num=int(input("enter the number:"))
temp=num
sums=0
while(num):
    i=1
    fact=1
    rem=num%10
    while(i<=rem):
        fact*=i
        i+=1
        sums+=fact
        num//=10
        if(sums==temp):
            print("given number is strong:")
        else:
            print("is not a strong number:")''''



3.#wap to find the square root of the given number

'''number=int(input("enter the number="))
square_root=number ** 0.5
print(int(square_root))'''


#input:
    enter the number=225
#output:    
    15


4.#WAP to find the Area of the traiangle
'''side_1=int(input("enter the side1="))
side_2=int(input("enter the side2="))
side_3=int(input("enter the side3="))
s=(side_1+side_2+side_3)/2
print(s)

Area_of_the_traiangle=(s*(s-side_1)*(s-side_2)*(s-side_3))**0.5

print(Area_of_the_traiangle)'''

#input:
enter the side1=8
enter the side2=9
enter the side3=7
#output:
12.0
26.832815729997478



5.#WAP for quadratic equation
a=float(input("enter the number="))
b=float(input("enter the number="))
c=float(input("enter the number="))
d=(b*b)-(4*a*c)
x=-b+(0.5**d)/(2*a)
y=-b-(0.5**d)/(2*a)      

print(x,y)

#input:
    4
    5
    6
#output:
    2.9514790517935283e+20 -2.9514790517935283e+20

6.#WAP to swap the 2 numbers
   
x=int(input("enter the number="))
y=int(input("enter the number="))
print("before swapping:" +str(x))
print("before  swapping:" +str(y))
z=x
x=y
y=z
print("after swapping:"+str(x))
print("after swappng:"+str(y))

#input:
enter the number=23
enter the number=67
#output:
before swapping:23
before  swapping:67
after swapping:67
after swappng:23


7.#WAP to convert kilometer to miles
'''kilo_meter=int(input("enter the number="))
miles=kilo_meter*0.621
print(miles)'''

#input:
kilometer=3
#output:
miles=1.863


8.#WAP to print its a leap year or not
"""Year=int(input("enter the number="))
if Year%400==0:
    print("its a leap year")
elif Year%100==0:
    print("its  not a  leap yaer")
elif Year%4==0:
    print("its a leap yaer")
else:
    print("its not a leap year")"""

#input:
enter the number=2020
#output:
its a leap yaer



9.#WAP to print the prime number or not
'''number_1=int(input("enter the number="))
number_2=int(input("enter the number="))

if number_1%2==1:
    print("its a prime number")
else:
    print("its not a prime")'''
    
#input:
enter the number=5
#output:
its a prime number


10.#WAP to find the factoial of the given number
'''fact_num=int(input("enter the number:"))
count=1
for i in range(1,fact_num+1):
    count *= i
print(count)'''

#input:
enter the number=5
#output:
120

11.# Program to display the Fibonacci sequence up to n-th term
'''
nterms = int(input("How many terms? "))
n1, n2 = 0, 1
count = 0

   print("Please enter a positive integer")
   
elif nterms == 1:
   print("Fibonacci sequence upto",nterms,":")
   print(n1)

else:
   print("Fibonacci sequence:")
   while count < nterms:
       print(n1)
       nth = n1 + n2
       # update values
       n1 = n2
       n2 = nth
       count += 1'''



12.#WAP to print the amstrong number in an  interval
'''lower = int(input("enter a lower range:", ))
upper = int(input("enter a upper range:", ))

for num in range(lower, upper+1 ):
    l = len(str(num))
    s = 0
    temp = num
    while temp > 0:
       digit = temp % 10
       s += digit ** l
       temp //= 10
       if num == s:
           print(num)'''

#input:
enter a lower range:100
enter a upper range:200
#output:
125
153


13.#WAP to print the amstrong number

a=int(input())
b=int(input())
for i in range(a,b+1):
    x=len(str(i))
    sum1=0
    temp=i
    while temp>0:
        digit=temp%10
        sum1+=digit**x
        temp//=10
    if i==sum1:
        print(i)
                          
#input:
    100
    200
#output:
    153


14.#WAP print the sum of natural numbers
'''num=int(input("enter the number="))
add=0
for i in range(num+1):
    add +=i
    num-=1
print("sum of the number=",add)'''

#input:
enter the number=15
#output:
120

16.#WAP to print to convert decimal value to binary,hexadecimal,octadecimal
num=int(input("enter the number="))
binary=bin(num)
hexadecimal=hex(num)
octadecimal=oct(num)
print(binary,hexadecimal,octadecimal)

#input:
enter the number=13
#output:
0b1101 0xd 0o15


17.#WAP for to find LCM
a=int(input())
b=int(input())
if a>b:
    great=a
else:
    great=b
lcm=False
for i in range(great,(a*b+1)):
    if not lcm:
        if(i%a)==0 and (i%b)==0:
            lcm=True
            great=i
print(great)


#input:
16
2
#output:
16

18.#WAP to  to find the HCF

a=int(input())
b=int(input())
if a>b:
    great=a
else:
    great=b
lcm=False
for i in range(great,(a*b+1)):
    if not lcm:
        if(i%a)==0 and (i%b)==0:
            lcm=True
            great=i
gcd=a*b//great
print(Hcf)

#input:
12
15
#output:
3



























15.#WAP to find the factors of the given number

'''M=int(input("enter the number:"))
lst=[]
for i in range(1,M+1):
    if M%i==0:
        lst.append(i)
print(lst)'''
#input:
enter the number:10
#output:
[1,2,5,10]






















8.#WAP to print the prime number or not
'''number_1=int(input("enter the number="))
number_2=int(input("enter the number="))

if number_1%2==1:
    print("its a prime number")
else:
    print("its not a prime")'''
    
#input:
enter the number=5
#output:
its a prime number









                        





