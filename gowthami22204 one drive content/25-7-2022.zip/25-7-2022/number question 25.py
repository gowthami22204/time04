#To print the square of the numbers in a given rangel
'''start = 1
end = 10
print("Square of the numbers the range from {0} and {1} are:".format(start, end))
for num in range(start, end):
    print(num ** 2)
#output:
Square of the numbers the range from 1 and 10 are:
1
4
9
16
25
36
49
64
81'''
    
=====================================================================================

#wap for eligibilty of candidates between the age limit 18 to 80
'''age=int(input ("enter the age="))
if age>18 and age<=80:
    print('your are eligilble')
else:
    print(' you are not eligible')

#output:
enter the age=56
your are eligilble
=================================================================================  
##wap to find the area of the circle

radius=int(input('enter the numner:'))
pi=3.14
Area_of_the_circle = pi * radius * radius
print('Area_of_the circle= ',Area_of_the_circle)

#output:
enter the numner:56
Area_of_the circle=  9847.04


=================================================================================
#WAP to print its a even or odd number

num=int(input("enter the number:"))
if num%2==0:
    print("its a even number")
else:
    print("its a odd number")
 ========================================================================================   

#WAP for finding  variables A and B are having the same memory location?
num1=int(input('enter the number:'))
print(id(num1))
num2=num1
print(id(num2))
#output:enter the number:5
2121990275440
2121990275440


====================================================================================
#WAP for calculating student marks in 5-subjects,and find  grades,(suppose grade A,B,C and Fail)?
hindi=int(input("enter the number:"))
telugu=int(input("enter the number:"))
english=int(input("enter the number:"))
maths=int(input("enter the number:"))
science=int(input("enter the number:"))
avg=(hindi+telugu+english+maths+science)/5
if(avg>=90):
    print("Grade: A")
elif(avg>=80 and avg<90):
    print("Grade: B")
elif(avg>=70 and avg<80):
    print("Grade: C")
elif(avg>=60 and avg<70):
    print("Grade: D")
else:
    print("Grade: F")








            
            
