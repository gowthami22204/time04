##1.Write a program which will find all such numbers which are divisible by 7 but are not a multiple of 5,
'''between 2000 and 3200 (both included). 
The numbers obtained should be printed in a comma-separated sequence on a single line.

num1=int(input())
num2=int(input())
sums=[]
for i in range(num1,num2+1):
    if  i%7==0 and i%5!=0:
        sums.append(i)
print(sums,end=" ")
#0utput:
2000
3200

[2002, 2009, 2016, 2023, 2037, 2044, 2051, 2058, 2072, 2079, 2086, 2093, 2107, 2114, 2121,
2128, 2142, 2149, 2156, 2163, 2177, 2184, 2191, 2198, 2212, 2219, 2226, 2233, 2247, 2254,
2261, 2268, 2282, 2289, 2296, 2303, 2317, 2324, 2331, 2338, 2352, 2359, 2366, 2373, 2387,
2394, 2401, 2408, 2422, 2429, 2436, 2443, 2457, 2464, 2471, 2478, 2492, 2499, 2506, 2513,
2527, 2534, 2541, 2548, 2562, 2569, 2576, 2583, 2597, 2604, 2611, 2618, 2632, 2639, 2646,
2653, 2667, 2674, 2681, 2688, 2702, 2709, 2716, 2723, 2737, 2744, 2751, 2758, 2772, 2779,
2786, 2793, 2807, 2814, 2821, 2828, 2842, 2849, 2856, 2863, 2877, 2884, 2891, 2898, 2912,
2919, 2926, 2933, 2947, 2954, 2961, 2968, 2982, 2989, 2996, 3003, 3017, 3024, 3031, 3038, 3052,
3059, 3066, 3073, 3087, 3094, 3101, 3108, 3122, 3129, 3136, 3143, 3157, 3164, 3171, 3178, 3192, 3199] 
=============================================================================================================


##2.Write a program which can compute the factorial of a given numbers. 

The results should be printed in a comma-separated sequence on a single line. 

Suppose the following input is supplied to the program: 

8 

Then, the output should be: 

40320


fact=1
for i in range(1,9):
    fact*=i
print(fact)
#output:
1
2
6
24
120
720
5040
40320
===================================================================================================================

##3.With a given integral number n, write a program to generate a dictionary thatcontains (i, i*i)
such that is an integral number between 1 and n (both included). and then the program should print the dictionary. 

Suppose the following input is supplied to the program: 

8 

Then, the output should be: 

{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64}

n=int(input())
x={ }
for i in range(1,n+1):
    x[i]=i*i
print(x)
    
###output:9
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64, 9: 81}

===================================================================================================================
##4. Write a program which accepts a sequence of comma-separated numbers from console and generate a list and a tuple which contains every number.  
Suppose the following input is supplied to the program:  
34,67,55,33,12,98  
Then, the output should be:  
['34', '67', '55', '33', '12', '98']  
('34', '67', '55', '33', '12', '98')


a = list(map(str,input().split()))
print(a)

##output:
34 67 55 33 12 98
['34', '67', '55', '33', '12', '98']


a = tuple(map(str,input().split()))
print(a)

##output:
34 67 55 33 12 98
('34', '67', '55', '33', '12', '98')


a=list(input().split())
print(a)

#output:
6 7 8 9 0 2 3 4 
['6', '7', '8', '9', '0', '2', '3', '4']


a=tuple(input().split())
print(a)

##output:
8 9 4 5 5 6 6
('8', '9', '4', '5', '5', '6', '6')


=================================================================================================================

##5.Write a program that accepts a comma separated sequence of words as input and prints the words in a comma-separated sequence after sorting them alphabetically. 

Suppose the following input is supplied to the program: 

without,hello,bag,world 

Then, the output should be: 

bag,hello,without,world 

str="without,hello,bag,world "
txt1=str.replace("without","bag")
txt2=txt1.replace("bag","without")
print(txt1)
print(txt2)



items =input("Input  words")
words = [word for word in items.split(",")]
print(",".join(sorted(list(set(words)))))

#OUTPUT:
Input  words:without,hello,bag,world
bag,hello,without,world
=========================================================================================================

## 6.Write a program that accepts sequence of lines as input and prints the lines after making all characters in the sentence capitalized. 

Suppose the following input is supplied to the program: 

Hello world 

Practice makes perfect 

Then, the output should be: 

HELLO WORLD 

PRACTICE MAKES PERFECT


x=input("enter the string:").split(",")
for i in x:
    print(i.upper())

##output:
    
enter the string:hello world,practice makes perfect
HELLO WORLD
PRACTICE MAKES PERFECT



s=input("enter the string:").split(",")
for i in s:
    print(i.upper())


enter the string:hello world,practice makes perfect
HELLO WORLD
PRACTICE MAKES PERFECT

===================================================================================================================
##7.Write a program which accepts a sequence of comma separated 4 digit binary numbers as its input and then
check whether they are divisible by 5 or not. The numbers that are divisible by 5 are to be printed in a comma
separated sequence. 

Example: 

0100,0011,1010,1001 

Then the output should be: 

1010 

Notes: Assume the data is input by console.



lst = []
s=[x for x in input().split(',')]
for i in s:
    inti = int(i, 2)
    if  inti % 5 ==0:
        lst.append(i)
print(','.join(lst))


##output:0100,0011,1010,1001 

1010


##8.Write a program that accepts a sentence and calculate the number of upper case letters and lower case
letter

Suppose the following input is supplied to the program: 

Hello world! 

Then, the output should be: 

UPPER CASE 1 

LOWER CASE 9

str="Hello world"
t={"UPPER_CASE":0,"LOWER_CASE":0}
for i in str:
    if i.isupper():
        t["UPPER_CASE"]+=1
    elif i.islower():
        t["LOWER_CASE"]+=1
    else:
        pass
print(str)
print("No. of Upper case characters : ", t["UPPER_CASE"])
print("No. of Lower case Characters : ", t["LOWER_CASE"])


##output::
Hello world
No. of Upper case characters :  1
No. of Lower case Characters :  9



##9.Convert 2nd Part of String into Upper Case:
str="hello world"

test_str = 'welcometopython'
 
print("The original string is : " + str(test_str))
hlf_idx = len(test_str) // 2
res = test_str[:hlf_idx] + test_str[hlf_idx:].upper()
         
print("The resultant string : " + str(res))

#output:
The original string is : welcometopython
The resultant string : welcomeTOPYTHON

##10.With a given tuple (1,2,3,4,5,6,7,8,9,10), write a program to print the first half values in one
line and the last half values in one line.'''

tuple=(0,1,2,3,4,5,6,7,8,9)
tp1=tuple[:5]
tp2=tuple[5:]
print(tp1)
print(tp2)

    



 
