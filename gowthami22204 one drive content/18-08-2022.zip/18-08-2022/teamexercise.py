##1.Write a Python program find a list of integers with exactly two
##occurrences of nineteen and at least three occurrences of five. 

'''Input: 

[19, 19, 15, 5, 3, 5, 5, 2] 

Output: 

True 

lst_1=input("enter any intergers:").split(',')
count=0
for i in lst_1:
    if i==19 and i==5:
        print(i)

        
items = [19, 19, 15, 5, 3, 5, 5, 2]
count = 0
count1 =0
for i in items:
    if i == 19 :
        count += 1
    if i==5:
        count1+=1
    elif count>=2 and count1==3:
        print(count)
        print(count1)
        print('true')




##output:
2
3
true



##2.WAPP to check a given list of integers where the sum of the integers is equal to length of list. 

items = [19, 1, 15, 5, 3, 5, 5, 2]
sum = 0

for i in items:
    sum+=i
print(sum)
if sum == len(items):
    print("true")
else:
    print("false")

##output:
55
false'''


##3.WAPP to add two integers without using arithmetic operator 

a=int(input("enter the number:"))
b=int(input("enter the number:"))
c=a^b
print(c) 
