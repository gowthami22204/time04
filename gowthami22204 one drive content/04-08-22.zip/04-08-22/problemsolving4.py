'''13. Write a Python program to find the strings in a given list, starting with a given prefix.
Input
[( ca,('cat', 'car', 'fear', 'center'))]
Output
['cat', 'car']
Input
[(do,('cat', 'dog', 'shatter', 'donut', 'at', 'todo'))]
Output
['dog', 'donut']


ls=['cat', 'car', 'fear', 'center']
pre="ca"
for ch in ls:
    if ch[:2]==pre:
        print(ch)
#output:
cat
car'''
ls=['cat', 'dog', 'shatter', 'donut', 'at', 'todo']
pre="do"
for ch in ls:
    if ch[:2]==pre:
        print(ch)
#output:
dog
donut
