
#list_questions


1.#take10 integer inputs from user and store them in a list and print them on screen.
a = list(map(int,input().split()))
print(a)

#output:
1 2 3 4 5 6 7 8 9 10
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]


2.Take 10 integer inputs from user and store them in a list. Again ask user to give a number. Now, tell user whether that number is present in list or not.
( Iterate over list using while loop ).

a = list(map(int,input().split()))
print(a)

n=int(input("enter a number"))
while n in a:
    print("True")
    break
else:   
    print("false")

#output:

1 23 3 45 67 8 89 9 9 10
[1, 23, 3, 45, 67, 8, 89, 9, 9, 10]
enter a number 5
false

    
Take 20 integer inputs from user and print the following:
number of positive numbers
number of negative numbers
number of odd numbers
number of even numbers
number of 0s.



4.Take 10 integer inputs from user and store them in a list. Now, copy all the elements in another list but in reverse order.

a = list(map(int,input().split()))
a.reverse()
print(a)


1 23 3  4 5  5 6 6 66 10
[10, 66, 6, 6, 5, 5, 4, 3, 23, 1]





#5.Write a program to find the sum of all elements of a list.
a=[0,1,2,3,4,5]
s=0
for i in a:
    s=s+i
print("Sum of list a is :", s)
'o/pSum of list a is : 15'



#6.Write a program to find the product of all elements of a list
a=[1,2,3,4,5]
p=1
for i in a:
    p=p*i
print("product of list a is :", p)
'o/p:product of list a is : 120'


#7.Initialize and print each element in new line of a list inside list.
my_list = [1, 2, 3, 4]
print(*my_list, sep="\n")


#8Find largest and smallest elements of a list.
a=[1,3,6,8,10]
print(min(a), max(a))
1 10


#9.Write a program to print sum, average of all numbers, smallest and largest element of a list.
a=[0,1,2,3,4,65]
s=0
n=len(a)
for i in a:
    s=s+i
    avg=s//n
print("Sum of list is", s,"average of all numbers", avg)
print(min(a), max(a))

#output:
sum=75
avg=17.5

#10Write a program to check if elements of a list are same or not it read from front or back.
#E.g.-
#2	3	15	15	3	2
l=[2,3,15,15,3,2]
ele=l[0]
chk=True
for i in l:
    if ele!=i:
        chk=False
        break
    if(chk==True):
        print("equal")
    else:
        print("not equal")


        
#11.Take a list of 10 elements. Split it into middle and store
    #the elements in two dfferent lists
"""a=[58, 24, 13, 15, 63, 9, 8, 81, 1, 78]

newlist1=a[:5]
newlist2=a[5:]
print(newlist1,newlist2)
'o\p[58, 24, 13, 15, 63] [9, 8, 81, 1, 78]''' 



