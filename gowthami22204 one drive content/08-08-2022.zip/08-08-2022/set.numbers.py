'''set.numbers


#1.  Add a list of elements to a given set
list_1=[2,3,45,56]
sets={2,45,6,78,89,7}
for i in list_1:
    sets.add(i)
print(sets)
#output:
{2, 3, 6, 7, 56, 89, 45, 78}




###2. Return a set of identical items from a given two Python":
set_1={2,4,45,56,77,89}
set_2={5,3,2,77,4,56,78}
print(set_1.intersection(set_2))

#output:
{56, 2, 4, 77}

###3.Returns a new set with all items from both sets by removing duplicates

set_1={1,2,3,45,6,7,89,0,23}
set_2={3,0,45,34,56,7,8,9,}
print(set_1.union(set_2))
#output:
{0, 1, 2, 3, 34, 6, 7, 8, 9, 45, 23, 56, 89}


##4.Given two Python sets, update first set with items that exist only
##in the first set and not in the second set.

set_1={'apple','banana','papaya','mango'}
set_2={'apple','mango','banana'}
print(set_1.difference(set_2))
#oputput:
{'papaya'}

##5.Remove 10, 20, 30 elements from a following set at once:
set_1={4,20, 30 ,10,50,40}
set_2={10,20, 30}
print(set_1.difference(set_2))

{40, 50, 4}

##6.Return a set of all elements in either A or B, but not both

set_1={10,20,30,50,70,40}
set_2={3,20,2,30,40,90,10}
print(set_1)

#output:

{50, 20, 70, 40, 10, 30}

##7.Determines whether or not the following two sets have any elements
##in common. If yes display the common elements

set_1={10,20,30,40,50,90}
set_2={40,50,60,70,80,90,100}
print(set_1.intersection(set_2))


#output:
{40, 50, 90}

###8. Update set1 by adding items from set2, except common items

set_1={1,2,3,4,6,7,40, 50, 90,9}
set_2={3,10,20,40,30,100}
for i in set_2:
    set_1.add(i)
print(set_1)
#0utput:{1, 2, 3, 4, 100, 6, 7, 40, 9, 10, 50, 20, 90, 30}
    

##9. Remove items from set1 that are not common to both set1 and set2:
set_1={2,3,5,66,7}
set_2={2,3,88,9,0}
print(set_1.difference(set_2))





##10.Write a Python program to check if a given set is superset of itself and superset of another given set

a={1,2,3,4,5,6,7,8}
b={1,2,3}
print(a.issuperset(b))

print(b.issuperset(a))

#output:
True
False



##11.Write a Python program to check a given set has no elements in common with other given set


a = {"e","i","o","u","a"}
b = {"d","r","y"}
s=set()
for i in a:
    if i in b:
        s.add(i)
if len(s)<1:
    print('there are no common elements')
else:
    print('common elements is present')
    
#output:
there are no common elements



##12.Write a Python program to remove the intersection of a 2nd set from the 1st set.

a={2,3,4,5,6}
b={8,9,7,6,3}
print(a-b)
#output:
{2, 4, 5}

##13. Perform all sets methods by taking an example of your own.
a={1,2,4,4,5,5,5}
b={"d","u","e"}
print(a.union(b))

{1, 2, 4, 5, 'd', 'e', 'u'}
##
a={"apple","banana","watermelon"}
b={"papaya"}
print(a.union(b))

#output:
{'watermelon', 'apple', 'banana', 'papaya'}'''

##
a={"w","e","l"}
b={"c","o","m","e" }
print(a.union(b))








