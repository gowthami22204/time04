#number.txt

##1.Write a program which will find all such numbers which are
divisible by 7 but are not a multiple of 5, between 2000 and 3200
(both included).
num1=int(input())
num2=int(input())
sums=[]
for i in range(num1,num2+1):
    if  i%7==0 and i%5!=0:
        sums.append(i)
print(sums,end=" ")        
       
#output:
[2002, 2009, 2016, 2023, 2037, 2044, 2051,
 2058, 2072, 2079, 2086, 2093, 2107, 2114,
 2121, 2128, 2142, 2149, 2156, 2163, 2177,
 2184, 2191, 2198, 2212, 2219, 2226, 2233,
 2247, 2254, 2261, 2268, 2282, 2289, 2296,
 2303, 2317, 2324, 2331, 2338, 2352, 2359,
 2366, 2373, 2387, 2394, 2401, 2408, 2422,
 2429, 2436, 2443, 2457, 2464, 2471, 2478,
 2492, 2499, 2506, 2513, 2527, 2534, 2541,
 2548, 2562, 2569, 2576, 2583, 2597, 2604,
 2611, 2618, 2632, 2639, 2646, 2653, 2667,
 2674, 2681, 2688, 2702, 2709, 2716, 2723,
 2737, 2744, 2751, 2758, 2772, 2779, 2786,
 2793, 2807, 2814, 2821, 2828, 2842, 2849,
 2856, 2863, 2877, 2884, 2891, 2898, 2912,
 2919, 2926, 2933, 2947, 2954, 2961, 2968,
 2982, 2989, 2996, 3003, 3017, 3024, 3031,
 3038, 3052, 3059, 3066, 3073, 3087, 3094,
 3101, 3108, 3122, 3129, 3136, 3143, 3157,
 3164, 3171, 3178, 3192, 3199, 3206, 3213,
 3227, 3234, 3241, 3248, 3262, 3269, 3276,
 3283, 3297, 3304, 3311, 3318, 3332, 3339,
 3346, 3353, 3367, 3374, 3381, 3388, 3402,
 3409, 3416, 3423, 3437, 3444, 3451, 3458,
 3472, 3479, 3486, 3493]

============================================================================================
##2.Write a program which can compute the factorial of a given numbers.
The results should be printed in a comma-separated sequence on a single line.
Suppose the following input is supplied to the program:

num=int(input())
som=1
for i in range(1,num+1):
    som *=i
print(som)


#output:8
40320


#output:

8
1
2
6
24
120
720
5040
40320

##
fact=1
for i in range(1,9):
    fact*=i
print(fact)
##output:
40320





========================================================================================================
3.With a given integral number n, write a program to generate a dictionary
that contains (i, i*i) such that is an integral number between 1 and n (both included).
and then the program should print the dictionary.
Suppose the following input is supplied to the program:
8
Then, the output should be:
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64}'''

n=int(input())
d={}
for i in range(1,n+1):
     d[i]=i*i
print(d)
    


================================================================================================

4.Write a program which accepts a sequence of comma-separated numbers from console and
generate a list and a tuple which contains every number.
Suppose the following input is supplied to the program:
34,67,55,33,12,98
Then, the output should be:
['34', '67', '55', '33', '12', '98']
('34', '67', '55', '33', '12', '98']

a = list(map(str,input().split()))
print(a)
#output:
34 67 55 33 12 98
['34', '67', '55', '33', '12', '98']'

a = tuple(map(str,input().split()))
print(a)
#output:
34 67 55 33 12 98
('34', '67', '55', '33', '12', '98')
===================================================================================================

5.Define a class which has at least two methods:
getString: to get a string from console input
printString: to print the string in upper case.
Also please include simple test function to test the class methods.
##printString: to print the string in upper case.


str="welcome to python"
print(str.upper())
#output=WELCOME TO PYTHON


====================================================================================
6.Write a program that calculates and prints the value according to the given formula:
Q = Square root of [(2 * C * D)/H]
Following are the fixed values of C and H:
C is 50. H is 30.
D is the variable whose values should be input to your program in a comma-separated sequence.
Example
Let us assume the following comma separated input sequence is given to the program:
100,150,180
The output of the program should be:
18,22,24



c=int(input())
h=int(input())
value=[]
x=list(map(int,input("enter the list of element : ").split(",")))
for d in x:
        value.append(str(int(float(q=[[(2*c*d)/h]%2]))))

print(','.join(value))

#output:
50
30
enter the list of element:100,150,180
18,22,24




===================================================================================================
7.Write a program which takes 2 digits, X,Y as input and generates a 2-dimensional array. The element
value in the i-th row and j-th column of the array should be i*j.
Note: i=0,1.., X-1; j=0,1,¡­Y-1.
Example
Suppose the following inputs are given to the program:
3,5
Then, the output of the program should be:
[[0, 0, 0, 0, 0], [0, 1, 2, 3, 4], [0, 2, 4, 6, 8]]

x=int(input())
y=int(input())
lst=[]
for i in range(0,x):
    lst1=[]
    for j in range(0,y):
        lst1.append(i*j)
    lst.append(lst1)

print(lst)
#o/p:[[0, 0, 0, 0, 0], [0, 1, 2, 3, 4], [0, 2, 4, 6, 8]]

==========================================================================================
8.Write a program that accepts a comma separated sequence of words as input and prints the words in a comma-separated sequence after sorting them alphabetically.
Suppose the following input is supplied to the program:
without,hello,bag,world
Then, the output should be:
bag,hello,without,world

str="without,hello,bag,world"
txt=str.replace("without","bag")
txt1=txt.replace("bag","without")

print(txt)
print(txt1)

##bag,hello,bag,world
without,hello,without,world



items =input("Input  words")
words = [word for word in items.split(",")]
print(",".join(sorted(list(set(words)))))

#OUTPUT:
Input  words:without,hello,bag,world
bag,hello,without,world

=========================================================================================


##9.Write a program that accepts sequence of lines as input and prints the lines after
making all characters in the sentence capitalized.
Suppose the following input is supplied to the program:
Hello world
Practice makes perfect
Then, the output should be:
HELLO WORLD
PRACTICE MAKES PERFECT
str="hello world \n practice makes perfesct\n"

print(str.upper())

#output:
HELLO WORLD 
 PRACTICE MAKES PERFESCT

s=input("enter the string:").split(",")
for i in s:
    print(i.upper())

 
##output:
enter the string:hello world,practice makes perfect
HELLO WORLD
PRACTICE MAKES PERFECT
===========================================================================================================
##10.Write a program that accepts a sequence of whitespace separated words as input and prints the words after
removing all duplicate words and sorting them alphanumerically.
Suppose the following input is supplied to the program:
hello world and practice makes perfect and hello world again
Then, the output should be:
again and hello makes perfect practice world'

a=input("enter the string:").split(" ")
print(" ".join(sorted(set(a))))


#output:
enter the string:hello world and practice makes perfect and hello world again
again and hello makes perfect practice world
===========================================================================================================
11.Write a program which accepts a sequence of comma separated 4 digit binary numbers as its input
and then check whether they are divisible by 5 or not. The numbers that are divisible by 5 are to
be printed in a comma separated sequence.
Example:
0100,0011,1010,1001
Then the output should be:
1010
Notes: Assume the data is input by console.


lst = []
s=[x for x in input().split(',')]
for p in s:
    intp = int(p, 2)
    if  intp % 5 ==0:
        lst.append(p)
print(','.join(lst))

0100,0011,1010,1001
1010


==========================================================================================================
12.Write a program, which will find all such numbers between 1000 and 3000 (both included) such that
each digit of the number is an even number.
The numbers obtained should be printed in a comma-separated
sequence on a single line.

x=int(input())
for i in range(1000,3000):
     
     if i%2==0:
        
         print(i,end=",")
        
#output:

[2000,2002,2004,2006,2008,2010,2012,2014,2016,2018,
2020,2022,2024,2026,
2028,2030,2032,2034,2036,2038,2040,2042,2044,2046,
2048,2050,2052,2054,2056,2058,2060,2062,2064,2066,
2068,2070,2072,2074,2076,2078,2080,2082,2084,2086,
2088,2090,2092,2094,2096,2098,2100,2102,2104,2106,
2108,2110,2112,2114,2116,2118,2120,2122,2124,2126,
2128,2130,2132,2134,2136,2138,2140,2142,2144,2146,
2148,2150,2152,2154,2156,2158,2160,2162,2164,2166,
2168,2170,2172,2174,2176,2178,2180,2182,2184,2186,
2188,2190,2192,2194,2196,2198,2200,2202,2204,2206,
2208,2210,2212,2214,2216,2218,2220,2222,2224,2226,
2228,2230,2232,2234,2236,2238,2240,2242,2244,2246,
2248,2250,2252,2254,2256,2258,2260,2262,2264,2266,
2268,2270,2272,2274,2276,2278,2280,2282,2284,2286,
2288,2290,2292,2294,2296,2298,2300,2302,2304,2306,
2308,2310,2312,2314,2316,2318,2320,2322,2324,2326,
2328,2330,2332,2334,2336,2338,2340,2342,2344,2346,
2348,2350,2352,2354,2356,2358,2360,2362,2364,2366,
2368,2370,2372,2374,2376,2378,2380,2382,2384,2386,
2388,2390,2392,2394,2396,2398,2400,2402,2404,2406,
2408,2410,2412,2414,2416,2418,2420,2422,2424,2426,
2428,2430,2432,2434,2436,2438,2440,2442,2444,2446,
2448,2450,2452,2454,2456,2458,2460,2462,2464,2466,
2468,2470,2472,2474,2476,2478,2480,2482,2484,2486,
2486,2488,2490,2492,2494,2496,2498,2500,2502,2504,
2506,2508,2510,2512,2514,2516,2518,2520,2522,2524
,2526,2528,2530,2532,2534,2536,2538,2540,2542,2544,
2546,2548,2550,2552,2554,2556,2558,2560,2562,2564,
2566,2568,2570,2572,2574,2576,2578,2580,2582,2584,
2586,2588,2590,2592,2594,2596,2598,2600,2602,2604,
2606,2608,2610,2612,2614,2616,2618,2620,2622,2624,
2626,2628,2630,2632,2634,2636,2638,2640,2642,2644
,2646,2648,2650,2652,2654,2656,2658,2660,2662,2664
,2666,2668,2670,2672,2674,2676,2678,2680,2682,2684,
2686,2688,2690,2692,2694,2696,2698,2700,2702,2704,
2706,2708,2710,2712,2714,2716,2718,2720,2722,2724,
2726,2728,2730,2732,2734,2736,2738,2740,2742,2744,
2746,2748,2750,2752,2754,2756,2758,2760,2762,2764,
2766,2768,2770,2772,2774,2776,2778,2780,2782,2784,
2786,2788,2790,2792,2794,2796,2798,2800,2802,2804,
2806,2808,2810,2812,2814,2816,2818,2820,2822,2824,
2826,2828,2830,2832,2834,2836,2838,2840,2842,2844,
2846,2848,2850,2852,2854,2856,2858,2860,2862,2864,
2866,2868,2870,2872,2874,2876,2878,2880,2882,2884,
2886,2888,2890,2892,2894,2896,2898,2900,2902,2904,
2906,2908,2910,2912,2914,2916,2918,2920,2922,2924,
2926,2928,2930,2932,2934,2936,2938,2940,2942,2944,
2946,2948,2950,2952,2954,2956,2958,2960,2962,2964,
2966,2968,2970,2972,2974,2976,2978,2980,2982,2984,
2986,2988,2990,2992,2994,2996,2998]
================================================================================
13.Write a program that accepts a sentence and calculate the number of letters and digits.
Suppose the following input is supplied to the program:
hello world! 123
Then, the output should be:
LETTERS 10
DIGITS 3
s = str(input("enter the string:"))
digits=0
letters=0
v=0

for i in s:
    if i.isalpha():
        letters += 1
    elif i.isdigit():
        digits += 1
    else:
        v +=1


print("number of letters found ", letters)
print("number of digits found ",digits)


enter the string:hello world!123
number of letters found  10
number of digits found  3












============================================================================================================

14.Write a program that accepts a sentence and calculate the number of upper case letters and lower case letters.
Suppose the following input is supplied to the program:
Hello world!
Then, the output should be:
UPPER CASE 1
LOWER CASE 9

def string_test(s):
    d={"UPPER_CASE":0, "LOWER_CASE":0}
    for i in s:
        if i.isupper():
           d["UPPER_CASE"]+=1
        elif i.islower():
           d["LOWER_CASE"]+=1
        else:
           pass
    print ("Original String : ", s)
    print ("No. of Upper case characters : ", d["UPPER_CASE"])
    print ("No. of Lower case Characters : ", d["LOWER_CASE"])

string_test('Hello world')

##output:

Original String :  Hello world
No. of Upper case characters :  1
No. of Lower case Characters :  9

str="Hello world"
t={"UPPER_CASE":0,"LOWER_CASE":0}
for i in str:
    if i.isupper():
        t["UPPER_CASE"]+=1
    elif i.islower():
        t["LOWER_CASE"]+=1
    else:
        pass
print(str)
print("No. of Upper case characters : ", t["UPPER_CASE"])
print("No. of Lower case Characters : ", t["LOWER_CASE"])

Hello world
No. of Upper case characters :  1
No. of Lower case Characters :  9









=====================================================================

15.Write a program that computes the value of a+aa+aaa+aaaa with a given digit as the value of a.
Suppose the following input is supplied to the program:
9
Then, the output should be:
11106
'''
n=int(input())
sums=0
for i in range(1,n):
     value=str(9)*i
     sums+=int(value)

print(sums)


#output:
5
11106



