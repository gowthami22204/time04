  # problem solving by TEAM1

Write a program to check whether the given password is valid or not .

conisder the password to be valid if it contain at least one digit ands one capital.



input:it will be a single line containng string

output: valid password or invalid password



ex:GJ22191gopi

ouput:valid password


l,u,p,d=0,0,0,0
s = "GJ22191@gopi"
if (len(s) >= 8):
    for i in s:
 
       
        if (i.islower()):
            l+=1           
 
        
        if (i.isupper()):
            u+=1
            
        if (i.isdigit()):
            d+=1
            
        if(i=='@'or i=='$' or i=='_'):
            p+=1          
if (l>=1 and u>=1 and p>=1 and d>=1 and l+p+u+d==len(s)):
    print("Valid Password")
else:
    print("Invalid Password")








