'''#Print First 10 natural numbers using while loop
n=int(input("enter the number:"))
i=1
while i<= n:
    print(i)
    i +=1
#input:10
#output:
    enter the number:10
1
2
3
4
5
6
7
8
9
10'''
======================================================================================================================
'''#Calculate the sum of all numbers from 1 to a given number
'n=int(input("enter the numbers:"))
sum=0
for i in range(1,n+1):
    sum+=i
    print(sum)'''
'''#input
enter the numbers:10
#output:
1
3
6
10
15
21
28
36
45
55'''
======================================================================================================================='''
n=int(input("enter the numbers:"))
count=0
for i in range(1,n+1):
    count+=i
    print(count)
#input:
enter the numbers:5
#output:
1
3
6
10
15'''
=======================================================================================================================


'''#Write a program to print multiplication table of a given number

n=int(input("enter the number:"))
for i in range(1,11):
    print(n,"*",i,"=",n*i)'''

'''#input:enter the number:5
#output:
5 * 1 = 5
5 * 2 = 10
5 * 3 = 15
5 * 4 = 20
5 * 5 = 25
5 * 6 = 30
5 * 7 = 35
5 * 8 = 40
5 * 9 = 45
5 * 10 = 50'''
=======================================================================================================================

'''#Display numbers from a list using loop
list=[2,4,6,8,99,0]
for i in list:
    print(i)

#output:2
4
6
8
99
0'''
=======================================================================================================================
'''#Count the total number of digits in a number

n=int(input("enter the numbers:"))
length=len(str(n))
print(length)

#input:
enter the numbers:456
#output
3'''
=======================================================================================================================
'''#Print list in reverse order using a loop
lst=[2,3,45,"hello",97,87,78]
for i in (lst[::-1]):
    print(i)
    
#output    
78
87
97
hello
45
3
2
=======================================================================================================================
'''7.#numbers from -10 to -1 using for loop Display
for  i in range(-10,-1+1):
    print(i)
#output:
-10
-9
-8
-7
-6
-5
-4
-3
-2
-1
=======================================================================================================================
8'''#Use else block to display a message “Done” after successful execution of for loop
n=int(input("enter the number:"))
if n%2==0:
    print("its a even number")
else:
    print("done")
======================================================================================================================
9#Write a program to display all prime numbers within a range
'''num1=int(input("enter the number:"))
num2=int(input("enter the number:"))

for i in range(num1,num2+1):
    if(num1>2):
        for i in range (2, num2):
            if (num2 % i) == 0:
                break
            else:
                print (num2)


=======================================================================================================================
#WAP to find the factoial of the given number'''
'''fact_num=int(input("enter the number:"))
count=1
for i in range(1,fact_num+1):
    count *= i
print(count)'''

'''#input:
enter the number=5
#output:
120'''
======================================================================================================================
# Program to display the Fibonacci sequence up to n-th term
'''
nterms = int(input("How many terms? "))
n1, n2 = 0, 1
count = 0

   print("Please enter a positive integer")
   
elif nterms == 1:
   print("Fibonacci sequence upto",nterms,":")
   print(n1)

else:
   print("Fibonacci sequence:")
   while count < nterms:
       print(n1)
       nth = n1 + n2
       # update values
       n1 = n2
       n2 = nth
======================================================================================================================       count += 1'''
'''#reverse of the string:
num=int(input("enter the number:"))
reverse=str(num)
reverse=reverse[::-1]
print(int(reverse))
inpupt:234
output:432'''
======================================================================================================================

'''#sum of the number in n seriews:
n=int(input("enter the number:"))
sum=0
for i in range(1,n+1):
    sum+=i
    print(sum)
    
#input:enter the number:8
#output:    
1
3
6
10
15
21
28
36'''
=======================================================================================================================
'''#calculate the cube of all  numbers from 1 to a given number:
n=[1,2,3,4]
res=[]
for i in n:
        res.append(i*i*i)
        print(res)
#output:[1]
[1, 8]
[1, 8, 27]
[1, 8, 27, 64]'''
===========================================================================================================================


'''#use a loop to dislay elements from a given list present at odd index positions
list=[2,3,4,5,56,67,78,90]
print('the odd number of elements in the list')
for i in range(0,len(list),2):
        print(list[i],end=" ")
#output:
the odd number of elements in the list
2 4 56 78 '''
=======================================================================================================================

'''#Name the keyword which helps in writing code involves condition. 

for,while,elif if

#There any limit of statement that can appear under an if block.
it is based upon the condition given by the user

#Name the keyword which helps in writing code involves condition
if,while,elif
=======================================================================================================================
#Write the syntax of simple if statement.
if(condition):
        statement1'''
        
'''#Write a program to check whether a person is eligible for voting or not. (accept age from user)         
age=int(input("enter the age:"))
if age>=18:
        print("The person is eligible to cast the vote")
else:
        print("The person is not eligible")'''
=======================================================================================================================
#Write a program to check whether a number entered by user is even or odd.

'''num=int(input("enter the number:"))
if num % 2==0:
        print('its a even number')
else:
        print('its a odd number')        


#output:
enter the number:4
its a even number
#output:
enter the number:7
its a odd number'''
======================================================================================================================================================================
'''#A program Write to check whether a number is divisible by 7 or not.
n=int(input("enter the number:"))
if n % 7==0:
        print("it is divisible by 7")
else:
        print("it is not divisible by 7")

output:
enter the number:56
it is divisible by 7'''
=======================================================================================================================
'''#Write a program to display "Hello" if a number entered by user is a multiple of five ,  

#otherwise print "Bye".

i=int(input("enter the number:"))
if i%5==0:
      print("hello")
else:
      print("byee")
#output:
enter the number:89
byee

enter the number:55
hello '''     
=======================================================================================================================
'''#Write a' program to calculate the electricity bill (accept number of unit from user) according to the following criteria : 
unit
Unit                                                     Price   

First 100 units                                               no charge 

Next 100 units                                              Rs 5 per unit 

After 200 units                                             Rs 10 per unit 

(For example if input unit is 350 than total bill amount is Rs2000)


units=int(input("enter the number of units  consumed:"))

if units<=100:
    print("no charges")
elif units>100:
       print(100*5)
elif units>200:
       print(units*10-1500)
else:
    print("pay the electricity bill")

#0utput:
     enter the number:100
0
  
enter the number of units  consumed:35
2000

enter the number of units  consumed:45
no charges

enter the number of units  consumed:123
500
=======================================================================================================================
25.#write a program to display the last digit of a number.
(hint : any number % 10 will return the last digit)
n=int(input("enter the number:"))
rem=n%10
while n!=10:
    print(rem)
    break
#output:
enter the number:100
0

enter the number:105
5'''
=======================================================================================================================
'''26.#Write a program to check whether the last digit of a number( entered by user ) is  
divisible by 3 or not.

n=int(input("enter the number:"))

if n%3==0:
    print('it is divisible by 3')
else:
    print('not divisible by 3')

#output:
    enter the number:33
it is divisible by 3

enter the number:53
not divisible by 3'''


============================================================================================================================ 
27.'''Write a program to accept percentage from the user and display the grade according to the following criteria: 

 Marks                                    Grade 

> 90                                       A  

ass.26.py                                  B                

>= 60 and <= 80                            C 

below 60                                   D

hindi=int(input("enter the number:"))
telugu=int(input("enter the number:"))
english=int(input("enter the number:"))
maths=int(input("enter the number:"))
science=int(input("enter the number:"))
avg=(hindi+telugu+english+maths+science)/5
if(avg>=90):
    print("Grade: A")
elif(avg>=80 and avg<90):
    print("Grade: B")
elif(avg>=70 and avg<80):
    print("Grade: C")
elif(avg>=60 and avg<70):
    print("Grade: D")
else:
    print("Grade: F")

#output:
enter the number:34
enter the number:67
enter the number:78
enter the number:98
enter the number:90
Grade: C
===========================================================================================================================
28.#program to check whether an years is leap year Write a or not. 

"""#leap yaer progaram

Year=int(input("enter the number="))
if Year%400==0:
    print("its a leap year")
elif Year%100==0:
    print("its  not a  leap yaer")
elif Year%4==0:
    print("its a leap yaer")
else:
    print("its not a leap year")"""

#input:
enter the number=2020
#output:
its a leap yaer












============================================================================================================================ 
28#write a program to accept the cost price of a bike and display the road tax to be paid according to the following criteria : 

     

        Cost price (in Rs)                                       Tax 

        > 100000                                                  15 % 

        > 50000 and <= 100000                                     10% 

        <= 50000                                                   5% 

============================================================================================================================ 29.Write a program to check whether an years is leap year or not. 

30.Write a program to accept a number from 1 to 7 and display the name of the day like 1 for Sunday , 2 for Monday
and so on.
week=int(intput("enter the number:"))






31.Write a program to accept a number from 1 to 12 and display name of the month and days in that month like 1 for January and number of days 31 and so on 

What do you mean by statement?

answer:the statement represents that an process need to carried out based on the condition given.
32.#Write the logical expression for the following: 

A is greater than B and C is greater than D

if a>b and c>d
============================================================================================================================ 

33.Accept any city from the user and display monument of that city. 

                  City                                 Monument 

                  Delhi                               Red Fort 

                  Agra                                Taj Mahal 

                  Jaipur                              Jal Mahal 

============================================================================================================================  

34.#Write the output of the following if a = 9 

         

    if (a > 5 and a <=10):     

         print("Hello")     

           else:     

        print("Bye")


#output:hello'''
============================================================================================================================         
'''
#Write a program to check whether a number entered is three digit number or not.

n=int(input())
if n>99 and n<999 :
print('its is a 3 digit number')
else:
print('its not')

#output:
23
its not

567
its is a 3 digit number


#36Write a program to check whether a person is eligible for voting or not.(voting age >=18)
age=int(input ("enter the age="))
if age>18 and age<=80:
    print('your are eligilble')
else:
    print(' you are not eligible')
   
#output:
enter the age=56
your are eligilble



#37Write a program to check whether a person is senior citizen or not.
age=int(input ("enter the age="))
if age<60 and age>60:
    print('he is sr citizen ')
else:
    print(' no he is not')
   
#output:
enter the age=67
he is the senior citizen

enter the age=23
 no he is not

#38.Write a program to find the lowest number out of two numbers excepted from user.

num_1=int(input("enter the number:"))
num_2=int(input("enter the number:"))
if num_1>num_2:
    print("num_1 is higher")
else:
    print("num_2is lower")

#output:
enter the number:83
enter the number:45
83 is higher
'''

#39.Write a program to find the largest number out of two numbers excepted from user.
num_1=int(input("enter the number:"))
num_2=int(input("enter the number:"))
if num_1>num_2:
    print("The  num1_1 is largest")
else:
    print("The num_1 is smaller")

#output:
enter the number:89
enter the number:67
The  num1_1 is largest


#40Write a program to check whether a number (accepted from user) is positive or negative.

num_1=int(input("enter the number:"))
num_2=int(input("enter the number:"))
if num_1>num_2:
    print("The  num1_1 is largest")
else:
    print("The num_1 is smaller")
#output:
enter the number:6
enter the number:-1
The  num1_1 is positive

enter the number:-5
enter the number:9
The num_1 is negative


41#Write a program to check whether a number is even or odd.
n=int(input("enter the number:"))
if n%2==0:
    print("its even")
else:
    print("its odd")
#output:
enter the number:4
its even

enter the number:9
its odd


#42.Write a program to whether a number (accepted from user) is divisible by 2 and 3 both.

n=int(input("enter the number:"))
if n%2==0:
    print("it is divisible by 2")
elif n%3==0:
    print("it is divisible by 3") 
else:
    print("none")
#output:
enter the number:50
it is divisible by 2

enter the number:45
it is divisible by 3

#43.Write a program to find the largest number out of three numbers excepted from user. 

a=int(input("enter the number:"))
b=int(input("enter the number:"))
c=int(input("enter the number:"))
if a>b and a>c:
    print(a)
elif:
    b>a and b>c:
else:
    print(c)

#output:
enter the number:2
enter the number:5
enter the number:8
8
44.Accept the temperature in degree Celsius of water and check whether it is boiling or not (boiling point of water in 100 oC. 









#The age of 4 people and display the youngest one and oldest one? Accept 
age1=int(input("enter the age:"))
age2=int(input("enter the age:"))
age3=int(input("enter the age:"))
age4=int(input("enter the age:"))

if age1>age2 and age1>age3 and age1>age4:
    print("age1 as elder")
elif age2>age1 and age2>age3 and age2>age4:
    print("age2 as elder")
elif age3>age1 and age3>age2 and age3>age4:
    print("age3 as elder")
else:
    print("age 4 is elder")

if age1<age2 and age1<age3 and age1<age4:
    print("age1 as younger")
elif age2<age1 and age2<age3 and age2<age4:
    print("age2 as younger")
elif  age3<age1 and age3<age2 and age3<age4:
    print("age3 as younger")
else:
    print("age 4 is younger")
#output:
enter the age:3
enter the age:4
enter the age:5
enter the age:6
age 4 is elder
age1 as younger














Accept the following from the user and calculate the percentage of class attended: 

 

a.     Total number of working days 

 

b.     Total number of days for absent 

 

    After calculating percentage show that, If the percentage is less than 75, than student will not be able to sit in exam. 

Accept three sides of a triangle and check whether it is an equilateral, isosceles or scalene triangle. 

 

Note : 

 

An equilateral triangle is a triangle in which all three sides are equal. 

 

A scalene triangle is a triangle that has three unequal sides. 

 

An isosceles triangle is a triangle with''' 



