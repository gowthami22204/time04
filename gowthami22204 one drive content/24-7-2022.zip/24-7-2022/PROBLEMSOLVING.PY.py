#swapping of numbers
x=int(input("enter the number="))
y=int(input("enter the number="))
print("before swapping:" +str(x))
print("before  swapping:" +str(y))
z=x
x=y
y=z
print("after swapping:"+str(x))
print("after swappng:"+str(y))
