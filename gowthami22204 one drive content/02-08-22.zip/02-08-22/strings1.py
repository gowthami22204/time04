#without builin functions


#1.WAP to print middle charactor of the string
"""txt="happymorning"
m=txt[(len(txt)//2)]
print("middle character of the string:", m)
middle character of the string: o"""


#2.2. WAP to print half reverse of the string 

"""Input: KNOWLEDGE
Output: EGDELKNOW"""
"""a='KNOWLEDGE'
m=len(a)//2
strit = a[0:m]
rev = a[-1:(m-1):-1]

print(rev + strit)
o/p:EGDELKNOW"""
# 3.WAP to remove all the vouels from the given string
"""a="this is a book"
b=("aeiou")
for i in a:
    if i not in b:
        print(i, end='')"""
"""o/p:ths s  bk"""
#4. WAP to insert * in front of every vouels in the string.

"""Input: BANANA
Output: B*AN*AN*A"""
"""a='BANANA'
b=('AEIOU')
for i in a:
    if i in b:
        print("*", i, end='')
        continue
    else:
        print(i, end='')"""
#5.WAP to count number of words in the string.
"""a="this is a book"
x=a"""
#6.6. WAP to remove extra space from the given string
"""a=" t his is a b ook "
count=0
list=[]
for i in  range (len(a)):
    if a[i]!=' ':
        list.append(a[i])
print(list)"""
#7. WAP to insert string in between the given string
"""Input: Ojas technologies 
Output: Ojas innovative technologies """
"""a='Ojas technologies'
x=a[0:5]+'innovative'+ ' '+ a[5::]
print(x)"""
'Ojas innovative technologies'
#WAP to find the ascci value of given char
#9.insert ojas in front of every string 
a="innovative"
print("ojas" + a)
#10.insert ojas in every extra space in the string 
"""a=input("enter a string : ")
for i in a:
    if i == " ":
        print(" ojas",i,end="")
        continue
    else:
        print(i,end="")"""
"""o/p:enter a string : this is a book
this ojas  is ojas  a ojas  book"""
