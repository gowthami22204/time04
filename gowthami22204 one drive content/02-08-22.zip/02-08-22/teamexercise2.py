1.WAP in python arrange string characters such that lowercase letters should come first
str='FGGGVVVVVVevggvcvvvvv'
print(str.upper())
print(str.lower())

string = "wFGHiiopkgfrtRTCFGiibzngfrx "
 
uppers = [l for l in string if l.isupper()]
print (''.join(uppers))
 
lowers = [l for l in string if l.islower()]
print (''.join(lowers))


FGHRTCFG
wiiopkgfrtiibzngfrx



2.Count the length of list with out using any inbuilt function.
list=[2,3,4,5,6,6,6]
print(len(list))


list=[2,4,5,6,7,8,9]
count=0
for i in list:
    count+=1
print(count)


#output:7


3.Write a Python program to create a histogram from a given list of integers.


list=[1,2,3,4,5]
for i in list:
    i='*'
    print(i,i**)'''


'''
4. Take input from user and if input is string print String
if input is integer/float print integer
if input is mix of string and integer print Error
HINT Can be done using ASCII code


str="hello"
"""inpt=input("Enter the string ")
int_counter=0
str_counter=0
for i in inpt:
    if ord(i)>48 and ord(i)<57:
        int_counter+=1
    elif (ord(i)>97 and ord(i)<122) or (ord(i)>65 and ord(i)<90) :
        str_counter+=1

if int_counter >0 and str_counter ==0:
    print("Integer")
elif int_counter == 0 and str_counter >0:
    print("String")
else:
    print("Error")

"""o\p:
Enter the string welcome
String"""

5.Python program to check if a string is palindrome or not

str=" madam"
w=""
for i in str:
    w=i+w
if w==str:
    print('true')
else:
    print('false')



#output:false

