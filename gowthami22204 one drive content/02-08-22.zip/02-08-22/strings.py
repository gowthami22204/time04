2/august/2022 9(exercise question)

1.WAP in python arrange string characters such that lowercase letters should come first
str='FGGGVVVVVVevggvcvvvvv'
print(str.upper())
print(str.lower())

string = "wFGHiiopkgfrtRTCFGiibzngfrx "
 
uppers = [l for l in string if l.isupper()]
print (''.join(uppers))
 
lowers = [l for l in string if l.islower()]
print (''.join(lowers))


FGHRTCFG
wiiopkgfrtiibzngfrx



2.Count the length of list with out using any inbuilt function.
list=[2,3,4,5,6,6,6]
print(len(list))


list=[2,4,5,6,7,8,9]
count=0
for i in list:
    count+=1
print(count)


#output:7


3.Write a Python program to create a histogram from a given list of integers.


list=[1,2,3,4,5]
for i in list:
    i='*'
    print(i,i**)'''

'''
4. Take input from user and if input is string print String
if input is integer/float print integer
if input is mix of string and integer print Error
HINT Can be done using ASCII code
str="hello"

5.Python program to check if a string is palindrome or not

str=" madam"
w=""
for i in str:
    w=i+w
if w==str:
    print('true')
else:
    print('false')

#output:false

2/aug/2022(practice sums)
1. How would you confirm that 2 strings have the same identity?

x="hello"
y="hello"
z="byeee"

print("str(x)==str(y)",str(x)==str(y))
print("str(x)==str(z)",str(x)==str(z))
print("id(str(x)=",id(str(x)))
print("id(str(y)=",id(str(y)))
print("id(str(z)=",id(str(z)))      

if id(str(x))==id(str(y)):
    print("its true")
elif id(str(x))==id(str(z)):
    print("its  not")
else:
    print("false")




2. How would you check if each word in a string begins with a capital letter?

x="hello"
print(x.isupper())
output:False

x="HelloS"
print(x[0].isupper())
output:True

3. Check if a string contains a specific substring
yes
for ex:

x="python"
x1="welcome to python"
print(x in x1)

output:"true"


4. Find the index of the first occurrence of a substring in a string

str="hello gowthami "
substring="hello gowthami welcome to python"
print(str.index("hello"))
print(substring.index("welcome"))
output:
     0
     15


5. Count the total number of characters in a string
str=" I love my country"
count=0
for i in str:
    count+=1
print(count)

output:
    18
6. Count the number of a specific character in a string

str="zoology"
count=0
print(str.count("o"))
#output=3

7. Capitalize the first character of a string

str="india"
print(str.capitalize())

#output:India
8. What is an f-string and how do you use it?

introducing new formal string into  a string is known as f-string or commonly known as formal string

09. Search a specific part of a string for a substring
str="welcome to python"
sudstring="to"
print(str.find("to"))

#output:8
10. Interpolate a variable into a string using format()
11.Check if a string contains only numbers

str="gow123the45"
if str==str.isdigit():
    print("the string consist of only digits")
else:
    print("consist of both alphabets and numarics")
   

#output:
consist of both alphabets and numarics





12. Split a string on a specific character
str="gowthami\nbelongs\nto\npython"
print(str.splitlines())

['gowthami', 'belongs', 'to', 'python']

13. Check if a string is composed of all lower case characters
str="hello india"
if str==str.lower():
    print("yes")
else:
    print("no")

#output:
    yes

14. Check if the first character in a string is lowercase'
str="hello world"

if str[0]==str[0].lower() :
    print("yes")
else:
    print("no")

#output:
    yes




15. Can an integer be added to a string in Python?
"yes"


16. Reverse the string “hello world”
str="hello world"
print(str[::-1])
# output:dlrow olleh


17. Join a list of strings into a single string, delimited by hyphens

list=["hello","world"]
print("_".join(list))

#output:
hello_world

18. Check if all characters in a string conform to ASCI
str="gowthami"



19. Uppercase or lowercase an entire string
str="gowthami"
print(str.upper())
print(str.lower())

#output:
GOWTHAMI
gowthami


20. Uppercase first and last character of a string
str="vedansh"
print(str[0:1].upper())
print(str[-1].lower())

#ouyput:
V
h

#21. Check if a string is all uppercase
str="HELLO"
if str==str.upper():
    print("yes")
else:
    print("no")

#OUTPUT:
yes

22. When would you use splitlines()?
python splitlines are used as line boundries in pyhton to split by using \r,\n etc
str="i\nlove\nmy\ncountry"
print(str.splitlines())
#output:
'I','love','my','country'


23. Give an example of string slicing'
slicing is nothing the retriving the characters from the given string by using the index number.
str="aeroplane"
print(str[0:4])

#outpu:aero

24. Convert an integer to a string
num=234
print("type before convertion:",type(num))
convertion_num=f'{num}'
print("type after convertion:",type(convertion_num))

#output:
type before convertion: <class 'int'>
type after convertion: <class 'str'>


25. Check if a string contains only characters of the alphabet

str="hello2022"
if str.isalpha() and str.isnumeric():
    print("true")
else:
    print("false")


26. Replace all instances of a substring in a string

input_string = "geeksforgeeks"
s1 = "geeks"
s2 = "french"
input_string = input_string.replace(s1, s2)
print(input_string)

#output:
frenchforfrench


27. Return the minimum character in a string
str="hello"
print(min(str))
#output:e


28. Check if all characters in a string are alphanumeric
str="gow123the45"
if str==str.isdigit():
    print("the string consist of only digits")
else:
    print("consist of both alphabets and numarics")
  

#output:
consist of both alphabets and numarics


29. Remove whitespace from the left, right or both sides of a string

str="  india  "
print(str.lstrip())
print(str.rstrip())



#output:india  
  india
    india









