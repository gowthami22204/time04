'''1. Write a program to get all vowels from given string?


word=input("Enter your word:")

for i in word:
    if i in ('a','e','i','o','u'):
        print(i,end=' ')

#output:

Enter your word:monsoon
o o o 



           
#================================================================================================== 

#2. Write a program to calculate the simple interest?


prince_amount=int(input("Enter your principle amount:"))
rate_return=int(input("Enter your rate of return percentage:"))
time_month=int(input("Enter your time in months:"))

tot=(prince_amount*rate_return*time_month)//100
print("Simple interest to return: ",tot)


#output:
Enter your principle amount:300000
Enter your rate of return percentage:20
Enter your time in months:24
Simple interest to return:  1440000







#================================================================================================== 

#3. Python Program to Find Sum of Series 1 + 1/2 + 1/3 + 1/4 + ……. + 1/N?


num=int(input("Enter your number:"))
s=1
for i in range(2,num+1):
    s=s+(1/i)
print(round(s,2))



#output:

Enter your number:4
2.08



#================================================================================================== 

#4. Python Program to Find the Sum of the Series 1/1!+1/2!+1/3!+…1/N!?



num=int(input("Enter your number:"))
s=0
for i in range(1,num+1):
    fact=1
    for j in range(1,i+1):
        fact=fact*j
    else:
        s=s+(1/fact)
print(round(s,3))

#Enter your number:66
1.718





#================================================================================================== 

#5. Python Program to Replace All Occurrences of ‘a’ with $ in a String?'''



word=input("enter word:")

for i in word:
    if i=='a':
        print('$',end='')
    else:
        print(i,end='')












##pr$veen b$noth

