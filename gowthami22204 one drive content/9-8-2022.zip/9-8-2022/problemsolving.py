

number = int(input("Enter the Natural Number: "))
for j in range(1, number+1):
    a = []
 
    
    for i in range(1, j+1):
        print(i, sep=" ", end=" ")
        if(i < j):
            print("+", sep=" ", end=" ")
        a.append(i)
    print("=", sum(a))
 
print()

'''
Enter the Natural Number: 4
1 = 1
1 + 2 = 3
1 + 2 + 3 = 6
1 + 2 + 3 + 4 = 10'''

Enter the Natural Number: 5
1 = 1
1 + 2 = 3
1 + 2 + 3 = 6
1 + 2 + 3 + 4 = 10
1 + 2 + 3 + 4 + 5 = 15


